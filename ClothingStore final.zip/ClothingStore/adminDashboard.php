<?php
include "DBConn.php";

$result = $conn->query("SELECT * FROM tblUser");

echo "<h2>Users</h2>";

while($row = $result->fetch_assoc()) {
    echo $row["username"] . "<br>";
}
?>