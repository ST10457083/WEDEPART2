<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION["userID"])) {
    header("Location: login.php");
}

$result = $conn->query("SELECT * FROM tblClothes");
?>

<h2>Welcome <?php echo $_SESSION["name"]; ?></h2>

<?php while($row = $result->fetch_assoc()) { ?>
    <div>
        <img src="images/<?php echo $row['imageName']; ?>" width="150">
        <p><?php echo $row['itemName']; ?></p>
        <p>R<?php echo $row['price']; ?></p>

        <a href="addToCart.php?id=<?php echo $row['clothesID']; ?>">
            <button>Add to Cart</button>
        </a>
    </div>
<?php } ?>

<a href="cart.php">Go to Cart</a>