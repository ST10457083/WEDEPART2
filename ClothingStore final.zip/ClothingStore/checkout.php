<?php
session_start();
include "DBConn.php";

$conn->query("DELETE FROM tblCart WHERE userID=".$_SESSION["userID"]);

echo "<h2>Order Successful </h2>";
echo "<a href='shop.php'>Back to shop</a>";
?>