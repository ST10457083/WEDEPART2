<!DOCTYPE html>
<html>
<head>
    <title>Hlomphos Clothing Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Pastimes Clothing Store</h2>
    <div>
        <a href="index.php">Home</a>
        <a href="shop.php">Shop</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="adminLogin.php">Admin</a>
    </div>
</div>

<!-- HERO SECTION -->
<div class="hero">
    <h1>Welcome to Hlomphos Clothing Store</h1>
    <p>Buy and sell second hand branded clothing easily</p>
    <a href="shop.php">
        <button>Start Shopping</button>
    </a>
</div>

<!-- SALE BANNER -->
<div class="sale-banner">

    <img src="Hoodie.jpeg" alt="Sale Left" class="sale-img">

    <div class="sale-content">
        <h2> Big Fashion Sale is Running!</h2>
        <p>Get up to <strong>50% OFF</strong> on selected second-hand clothing.</p>

        <a href="shop.php">
            <button>View Sale Items</button>
        </a>
    </div>

    <img src="Hoodie2.jpeg" alt="Sale Right" class="sale-img">

</div>

<!-- FEATURES SECTION -->
<div class="features">

    <div class="feature-box">
        <img src="BuyClothes.jpeg" alt="Buy Clothes">
        <h3>🛍 Buy Clothes</h3>
        <p>Browse affordable second-hand fashion items.</p>
    </div>

    <div class="feature-box">
        <img src="SellClothes.jpeg" alt="Sell Clothes">
        <h3> Sell Clothes</h3>
        <p>Upload and sell your clothing items easily.</p>
    </div>

    <div class="feature-box">
        <img src="SecureSystem.jpeg" alt="Secure System">
        <h3> Secure System</h3>
        <p>Admin verification ensures trusted users.</p>
    </div>

</div>

<!-- FOOTER -->
<div class="footer">
    <p>&copy; 2026 Pastimes Clothing Store | All Rights Reserved</p>
</div>

</body>
</html>