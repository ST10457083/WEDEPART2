<?php
include "DBConn.php";

$conn->query("CREATE DATABASE IF NOT EXISTS ClothingStore");
$conn->select_db("ClothingStore");

$conn->query("DROP TABLE IF EXISTS tblCart");
$conn->query("DROP TABLE IF EXISTS tblClothes");
$conn->query("DROP TABLE IF EXISTS tblUser");
$conn->query("DROP TABLE IF EXISTS tblAdmin");

$conn->query("
CREATE TABLE tblUser (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100),
    email VARCHAR(100),
    username VARCHAR(50),
    passwordHash VARCHAR(255),
    verificationStatus VARCHAR(20) DEFAULT 'verified'
)");

$conn->query("
CREATE TABLE tblAdmin (
    adminID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    passwordHash VARCHAR(255)
)");

$conn->query("
CREATE TABLE tblClothes (
    clothesID INT AUTO_INCREMENT PRIMARY KEY,
    itemName VARCHAR(100),
    brand VARCHAR(50),
    size VARCHAR(20),
    colour VARCHAR(20),
    price DECIMAL(10,2),
    imageName VARCHAR(100)
)");

$conn->query("
CREATE TABLE tblCart (
    cartID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT,
    clothesID INT
)");

$pass = password_hash("abc", PASSWORD_DEFAULT);

$conn->query("
INSERT INTO tblUser(fullName,email,username,passwordHash)
VALUES ('John Doe','john@gmail.com','john','$pass')
");

$conn->query("
INSERT INTO tblClothes(itemName,brand,size,colour,price,imageName)
VALUES
('Nike Hoodie','Nike','M','Black',250,'Hoodie.jpeg'),
('Adidas Hoodie','Adidas','L','Grey',300,'Hoodie2.jpeg')
");

$adminPass = password_hash("admin123", PASSWORD_DEFAULT);

$conn->query("
INSERT INTO tblAdmin(username,passwordHash)
VALUES ('admin','$adminPass')
");

echo "Database Ready ";
?>