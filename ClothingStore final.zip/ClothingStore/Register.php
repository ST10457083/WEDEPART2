<?php
include "DBConn.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullName = $_POST["fullName"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validation
    if ($fullName == "" || $email == "" || $username == "" || $password == "") {
        $message = "Please fill in all required fields.";
    } else {

        // Hash password
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Insert into DB
        $stmt = $conn->prepare("
            INSERT INTO tblUser (fullName, email, username, passwordHash, verificationStatus)
            VALUES (?, ?, ?, ?, 'pending')
        ");

        $stmt->bind_param("ssss", $fullName, $email, $username, $passwordHash);

        if ($stmt->execute()) {
            $message = "Registration successful. Wait for admin approval.";
        } else {
            $message = "Username or email already exists.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Pastimes</h2>
    <div>
        <a href="index.php">Home</a>
        <a href="login.php">Login</a>
    </div>
</div>

<!-- REGISTER FORM -->
<div class="container">
    <h2>Create Account</h2>

    <p class="error"><?php echo $message; ?></p>

    <form method="POST">
        <input type="text" name="fullName" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Register</button>
    </form>

    <p style="text-align:center; margin-top:10px;">
        <a href="login.php">Already have an account? Login</a>
    </p>
</div>

</body>
</html>