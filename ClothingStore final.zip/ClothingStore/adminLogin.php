<?php
session_start();
include "DBConn.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $res = $conn->query("SELECT * FROM tblAdmin WHERE username='$username'");

    if ($res->num_rows > 0) {
        $admin = $res->fetch_assoc();

        if (password_verify($password, $admin["passwordHash"])) {
            $_SESSION["adminID"] = $admin["adminID"];
            header("Location: adminDashboard.php");
            exit();
        } else {
            $message = "Wrong password";
        }
    } else {
        $message = "Admin not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Admin Panel</h2>
    <div>
        <a href="index.php">Home</a>
        <a href="login.php">User Login</a>
    </div>
</div>

<!-- ADMIN LOGIN -->
<div class="container">
    <h2>Admin Login</h2>

    <p class="error"><?php echo $message; ?></p>

    <form method="POST">
        <input type="text" name="username" placeholder="Admin Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>