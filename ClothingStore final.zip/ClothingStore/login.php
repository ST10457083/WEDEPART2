<?php
session_start();
include "DBConn.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = $conn->query("SELECT * FROM tblUser WHERE username='$username'");

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["passwordHash"])) {
            $_SESSION["userID"] = $user["userID"];
            $_SESSION["name"] = $user["fullName"];

            header("Location: shop.php");
            exit();
        } else {
            $message = "Wrong password";
        }
    } else {
        $message = "User not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>Pastimes</h2>
    <div>
        <a href="index.php">Home</a>
        <a href="shop.php">Shop</a>
        <a href="register.php">Register</a>
    </div>
</div>

<!-- LOGIN BOX -->
<div class="container">
    <h2>User Login</h2>

    <p class="error"><?php echo $message; ?></p>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Login</button>
    </form>

    <p style="text-align:center; margin-top:10px;">
        <a href="register.php">Create account</a>
    </p>
</div>

</body>
</html>