<?php
session_start();
include "DBConn.php";

$userID = $_SESSION["userID"];

$result = $conn->query("
SELECT tblCart.cartID, tblClothes.*
FROM tblCart
JOIN tblClothes ON tblCart.clothesID = tblClothes.clothesID
WHERE tblCart.userID = $userID
");

$total = 0;
?>

<h2>Your Cart</h2>

<?php while($row = $result->fetch_assoc()) {
    $total += $row["price"];
?>
    <p><?php echo $row["itemName"]; ?> - R<?php echo $row["price"]; ?></p>
    <a href="removeCart.php?id=<?php echo $row['cartID']; ?>">Remove</a>
<?php } ?>

<h3>Total: R<?php echo $total; ?></h3>

<form method="POST" action="checkout.php">
<input type="text" name="address" placeholder="Delivery Address">
<button>Checkout</button>
</form>