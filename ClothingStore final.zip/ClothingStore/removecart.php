<?php
include "DBConn.php";

$id = $_GET["id"];

$conn->query("DELETE FROM tblCart WHERE cartID=$id");

header("Location: cart.php");
?>