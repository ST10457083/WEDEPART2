<?php
session_start();
include "DBConn.php";

$userID = $_SESSION["userID"];
$id = $_GET["id"];

$conn->query("INSERT INTO tblCart(userID, clothesID) VALUES ($userID, $id)");

header("Location: cart.php");
?>